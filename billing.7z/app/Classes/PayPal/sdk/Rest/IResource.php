<?php

namespace Pterodactyl\Classes\PayPal\sdk\Rest;

/**
 * Interface IResource
 *
 * @package PayPal\Rest
 */
interface IResource
{
}
